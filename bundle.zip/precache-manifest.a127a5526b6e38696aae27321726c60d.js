self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f587b2db15a0f3ba2f38f9c5dad4410d",
    "url": "/index.html"
  },
  {
    "revision": "542f90cc6dbe340bf131",
    "url": "/static/css/2.ed87aa75.chunk.css"
  },
  {
    "revision": "a86373fb57316d48df24",
    "url": "/static/css/main.3e24912e.chunk.css"
  },
  {
    "revision": "542f90cc6dbe340bf131",
    "url": "/static/js/2.debdf3ca.chunk.js"
  },
  {
    "revision": "74c0ddca854ac003128884c6311253d0",
    "url": "/static/js/2.debdf3ca.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a86373fb57316d48df24",
    "url": "/static/js/main.9ebdf187.chunk.js"
  },
  {
    "revision": "4db5311a8a60a8617a6e",
    "url": "/static/js/runtime-main.65a875c1.js"
  },
  {
    "revision": "bff9e389031e53800143033b7674b4ce",
    "url": "/static/media/Board1.bff9e389.svg"
  },
  {
    "revision": "c32f376ce6a68e8d35b3cf4addbc3b98",
    "url": "/static/media/Board2.c32f376c.svg"
  },
  {
    "revision": "353d3a8073044c9f36809b726057eecf",
    "url": "/static/media/Board3.353d3a80.svg"
  },
  {
    "revision": "979bfd08f6189d7ded86260d106162f9",
    "url": "/static/media/Board4.979bfd08.svg"
  },
  {
    "revision": "5e950831387565c400c94f6ec86f4af4",
    "url": "/static/media/Board5.5e950831.svg"
  }
]);