self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "38fea749543ad9cc28f31b90e6adb2b7",
    "url": "/index.html"
  },
  {
    "revision": "891ab7581ee001f32a22",
    "url": "/static/css/2.ed87aa75.chunk.css"
  },
  {
    "revision": "4592119fe0701dc4df32",
    "url": "/static/css/main.4460530b.chunk.css"
  },
  {
    "revision": "891ab7581ee001f32a22",
    "url": "/static/js/2.35256cbf.chunk.js"
  },
  {
    "revision": "74c0ddca854ac003128884c6311253d0",
    "url": "/static/js/2.35256cbf.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4592119fe0701dc4df32",
    "url": "/static/js/main.b8ee244a.chunk.js"
  },
  {
    "revision": "4db5311a8a60a8617a6e",
    "url": "/static/js/runtime-main.65a875c1.js"
  },
  {
    "revision": "bff9e389031e53800143033b7674b4ce",
    "url": "/static/media/Board1.bff9e389.svg"
  },
  {
    "revision": "c32f376ce6a68e8d35b3cf4addbc3b98",
    "url": "/static/media/Board2.c32f376c.svg"
  },
  {
    "revision": "353d3a8073044c9f36809b726057eecf",
    "url": "/static/media/Board3.353d3a80.svg"
  },
  {
    "revision": "979bfd08f6189d7ded86260d106162f9",
    "url": "/static/media/Board4.979bfd08.svg"
  },
  {
    "revision": "5e950831387565c400c94f6ec86f4af4",
    "url": "/static/media/Board5.5e950831.svg"
  }
]);